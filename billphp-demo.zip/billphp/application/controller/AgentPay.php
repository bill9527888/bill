<?php
namespace app\controller;

class AgentPay
{
  private $appkey;
  private $appSecret;
  private $host;
  function __construct()
  {
    $this->appkey = "c3246abfcddb46f3a26c845f06b8a293";
    $this->appSecret = "a62e17090db0e808a6ab3675a41bc06b";
    $this->host = "http://pay-test.cpayxx.com/api/exchange";
  }

  /**
   * 代付接口
   */
  public function create()
  {
    $parame = [
      'appKey' => $this->appkey,
      'outOrderId' => random_str(36), //订单号，不超过 36 位
      'payAmount' => 100, //下单金额，不能小于 100
      'payType' => 1, // 支付方式：1-银行卡，21-支付宝转银行卡
      'payeeName' => '张三', //收款人名称,收款人错误将导致代付失败
      'payeeAccount' => '62***********', // 收款人银行卡号，卡号错误将导致代付失败
      'accountBankName' => '中国银行', // 银行名称，必填，银行名错误可能导致代付失败
      'branchBankName' => '北京支行', // 开户支行名称,选填，
      'receiveUrl' => 'http://localhost/agentpay/notice', //后台通知回调地址，支付成功后收到回调信息
      'timestamp' => \time(),
      'noncestr' => \random_str(12)
    ];
    $sign = md5($parame['payeeName'].$parame['payeeAccount'].$parame['payAmount'].$parame['receiveUrl'].$parame['noncestr'].$parame['timestamp'].'MD5'.$this->appSecret);
    $parame['sign'] = $sign;
    list($returnCode, $returnContent) = http_post_json($this->host.'/api/open/agentPay/orderCreate/'.$this->appkey, $parame);
    if ($returnCode == 200) {
      $result = json_decode($returnContent, true);
      if ($result['code'] == 0) { // code 为 0请求成功
        $orderId = $result['data']; // 平台的代付编号
        // Header("Location: $payPageUrl");
      }
    }
    return \think\Response::create(json_decode($returnContent, true), 'json', $returnCode);
  }

  /**
   * 回调通知
   */
  public function notice()
  {
    $parame = input('.post');
    // 验证签名
    $sign = md5($parame['customerAmount'].$parame['customerAmountCny'].$parame['outOrderId'].$parame['orderId'].$parame['signType'].$parame['status'].$this->appSecret);
    if ($sign == $parame['sign']){
      //签名正确，订单成功，根据outOrderId 和 customerAmountCny（客户实际支付金额）处理业务逻辑
    }
  }

  /***
   * 订单查询
   */
  public function query($outOrderId)
  {
    $parame = [
      'appKey' => $this->appkey,
      'outOrderId' => $outOrderId, //商户订单号，不超过 36 位
    ];
    list($returnCode, $returnContent) = http_post_json($this->host.'/api/open/agentPay/queryOrder', $parame);
    if ($returnCode == 200) {
      
      $result = json_decode($returnContent, true);
      if ($result['code'] == 0) { 
        $data = $result['data'][0];
        // var_dump($data);
        if ($data['status'] == 3 || $data['status'] == 10){
          // 代付成功
        }else if ($data['adOrderStatus'] == 2 && (isset($data['status']) || $data['status'] == 6)){
          // 代付失败
        }else {
          // 代付进行中
        }

      }
    }
    return \think\Response::create(json_decode($returnContent, true), 'json', $returnCode);
  }
}