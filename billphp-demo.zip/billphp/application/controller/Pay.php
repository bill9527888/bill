<?php
namespace app\controller;

class Pay
{
  private $appkey;
  private $appSecret;
  private $host;
  function __construct()
  {
    $this->appkey = "c3246abfcddb46f3a26c845f06b8a293";
    $this->appSecret = "a62e17090db0e808a6ab3675a41bc06b";
    $this->host = "http://pay-test.cpayxx.com/api/exchange";
  }

  /**
   * 下单接口
   */
  public function golden()
  {
    $parame = [
      'appKey' => $this->appkey,
      'outOrderId' => random_str(36), //订单号，不超过 36 位
      'customerAmountCny' => 100, //下单金额，不能小于 100
      'payType' => 21, // 支付方式：1-银行卡，21-支付宝转银行卡
      'payerName' => '张三', //付款人名称,不超过 30 位，可以是平台用户的唯一标识
      'receiveUrl' => 'http://localhost/pay/notice' //后台通知回调地址，支付成功后收到回调信息
    ];
    $sign = md5($parame['outOrderId'].$parame['receiveUrl'].$parame['customerAmountCny'].'MD5'.$this->appSecret);
    $parame['sign'] = $sign;
    list($returnCode, $returnContent) = http_post_json($this->host.'/api/open/golden/'.$this->appkey, $parame);
    if ($returnCode == 200) {
      $result = json_decode($returnContent, true);
      if ($result['code'] == 0) { // code 为 0请求成功
        $data = $result['data'];
        $payPageUrl = $data['payPageUrl'];  // 此网址为向用户展示的付款引导页，前端展示此网页地址即可
        // Header("Location: $payPageUrl");
      }
    }
    return \think\Response::create(json_decode($returnContent, true), 'json', $returnCode);
  }

  /**
   * 回调通知
   */
  public function notice()
  {
    $parame = input('.post');
    // 验证签名
    $sign = md5($parame['customerAmount'].$parame['customerAmountCny'].$parame['outOrderId'].$parame['orderId'].$parame['signType'].$parame['status'].$this->appSecret);
    if ($sign == $parame['sign']){
      //签名正确，订单成功，根据outOrderId 和 customerAmountCny（客户实际支付金额）处理业务逻辑
    }
  }

  /***
   * 订单查询
   */
  public function query($outOrderId)
  {
    $parame = [
      'appKey' => $this->appkey,
      'orderId' => $outOrderId, //商户订单号，不超过 36 位
    ];
    list($returnCode, $returnContent) = http_post_json($this->host.'/api/open/buy/orderInfo', $parame);
    if ($returnCode == 200) {
      $result = json_decode($returnContent, true);
      if ($result['code'] == 0) { 
        
        $data = $result['data'][0];
        // var_dump($data);
        if ($data['status'] == 4 && $data['objectionStatus'] == 2){
          // 支付成功
        }else if ($data['status'] == 6 && $data['objectionStatus'] == 2){
          // 支付失败
        }else {
          // 支付进行中
        }

      }
    }
    return \think\Response::create(json_decode($returnContent, true), 'json', $returnCode);
  }

  /***
   * 订单取消
   */
  public function cancel($orderId, $outOrderId)
  {
    $parame = [
      'appKey' => $this->appkey,
      'operateType' => 'cancel',
      'orderId' => $orderId, // 下单后，返回的平台的订单号
      'outOrderId' => $outOrderId, //商户订单号，不超过 36 位
      'reason' => '取消订单', // 取消原因
      'payType' => 21, // 支付方式：1-银行卡，21-支付宝转银行卡
      'payerName' => '张三', //付款人名称,不超过 30 位，可以是平台用户的唯一标识
    ];
    $sign = md5($parame['operateType'].$parame['orderId'].$parame['outOrderId'].$parame['payerName'].$parame['payType'].$this->appSecret);
    $parame['sign'] = $sign;
    list($returnCode, $returnContent) = http_post_json($this->host.'/api/open/change/golden/paymentCode', $parame);
    if ($returnCode == 200) {
      $result = json_decode($returnContent, true);
      if ($result['code'] == 0) { // code 为 0 取消成功
        
      }
    }
    return \think\Response::create(json_decode($returnContent, true), 'json', $returnCode);
  }
}